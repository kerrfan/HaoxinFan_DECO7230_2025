using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.CollabProxy.Editor")]
[assembly: InternalsVisibleTo("Unity.PlasticSCM.Editor.Entities")]
[assembly: InternalsVisibleTo("Unity.PlasticSCM.EditorTests")]
[assembly: InternalsVisibleTo("Unity.PlasticSCM.DevTools")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
