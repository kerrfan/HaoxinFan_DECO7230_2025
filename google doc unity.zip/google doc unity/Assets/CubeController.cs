using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class CubeController : MonoBehaviour, IPointerClickHandler, IDragHandler, IScrollHandler, IPointerUpHandler, IBeginDragHandler
{
    public float moveSpeed = 5f;
    public float scaleSpeed = 0.1f;
    public Transform boundary;
    public float rotationSpeed = 100f;

    private bool isDragging;
    private Vector3 initialDragPosition;
    private Vector3 initialObjectPosition;

    public GameObject show;

    private void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");
        Vector3 move = new Vector3(horizontal, 0, vertical) * moveSpeed * Time.deltaTime;
        Vector3 newPosition = transform.position + move;

        float boundaryHalfWidth = boundary.localScale.x / 2;
        float boundaryHalfHeight = boundary.localScale.y / 2;
        float boundaryHalfDepth = boundary.localScale.z / 2;

        newPosition.x = Mathf.Clamp(newPosition.x, boundary.position.x - boundaryHalfWidth, boundary.position.x + boundaryHalfWidth);
        newPosition.z = Mathf.Clamp(newPosition.z, boundary.position.z - boundaryHalfDepth, boundary.position.z + boundaryHalfDepth);

        if (!isDragging)
        {
            transform.position = newPosition;
        }

        if (Input.GetKey(KeyCode.Alpha1))
        {
            transform.Rotate(Vector3.right * rotationSpeed * Time.deltaTime);
        }
        else if (Input.GetKey(KeyCode.Alpha2))
        {
            transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime);
        }
        else if (Input.GetKey(KeyCode.Alpha3))
        {
            transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);
        }
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (show.activeInHierarchy) return;
        if (!isDragging)
        {
            Debug.Log("Cube Clicked!");
            show.SetActive(true);
        }
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (show.activeInHierarchy) return;
        isDragging = true;
        initialDragPosition = eventData.position;
        initialObjectPosition = transform.position;
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (show.activeInHierarchy) return;
        if (isDragging)
        {
            Vector3 currentDragPosition = eventData.position;
            Vector3 positionDelta = currentDragPosition - initialDragPosition;

            Vector3 newPosition = initialObjectPosition;
            newPosition.x += positionDelta.x / Screen.width * boundary.localScale.x;
            newPosition.y += positionDelta.y / Screen.height * boundary.localScale.y;
            newPosition.z = transform.position.z;

            float boundaryXMin = boundary.position.x - boundary.localScale.x / 2;
            float boundaryXMax = boundary.position.x + boundary.localScale.x / 2;
            float boundaryYMin = boundary.position.y - boundary.localScale.y / 2;
            float boundaryYMax = boundary.position.y + boundary.localScale.y / 2;

            newPosition.x = Mathf.Clamp(newPosition.x, boundaryXMin, boundaryXMax);
            newPosition.y = Mathf.Clamp(newPosition.y, boundaryYMin, boundaryYMax);

            transform.position = newPosition;
        }
    }

    public void OnScroll(PointerEventData eventData)
    {
        if (show.activeInHierarchy) return;
        float scrollDelta = eventData.scrollDelta.y;
        Vector3 newScale = transform.localScale + new Vector3(scrollDelta, scrollDelta, scrollDelta) * scaleSpeed;

        float minScale = 0.1f;
        float maxScale = 5f;
        newScale.x = Mathf.Clamp(newScale.x, minScale, maxScale);
        newScale.y = Mathf.Clamp(newScale.y, minScale, maxScale) * 0.2f;
        newScale.z = Mathf.Clamp(newScale.z, minScale, maxScale);

        transform.localScale = newScale;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        isDragging = false;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        isDragging = false;
    }
}